# Android — Martino Finance

La version `web/` est conçue pour être responsive et installable comme PWA une fois publiée en HTTPS.

Pour l'installer sur Android :
1. Publier le dossier `web` sur un hébergement HTTPS.
2. Ouvrir l'adresse du site sur Android dans Chrome.
3. Utiliser le menu ⋮ > « Installer l'application » ou « Ajouter à l'écran d'accueil ».

Cette méthode produit une application web installée, pas un APK natif. Pour générer un APK, il faudra créer un projet Android Studio (par exemple une Trusted Web Activity ou une WebView correctement sécurisée), signer le paquet et le tester. Ne connectez pas de fonctions financières réelles avant audit de sécurité et conformité réglementaire.
