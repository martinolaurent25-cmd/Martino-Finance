# Martino Finance — prototype

## Fichiers
- `web/index.html`: site responsive avec interactions locales
- `web/manifest.json`: métadonnées de type PWA
- `web/sw.js`: service worker minimal pour mise en cache

## Tester sur ordinateur
Ouvrir `web/index.html` dans un navigateur. Certaines fonctions d'installation PWA nécessitent HTTPS.

## Publier gratuitement (exemple)
1. Créer un compte GitHub.
2. Créer un dépôt public nommé `martino-finance`.
3. Envoyer les trois fichiers du dossier `web` à la racine du dépôt (ou placer leur contenu à la racine).
4. Dans Settings > Pages, choisir la branche principale et le dossier racine.
5. Attendre l'URL publiée par GitHub Pages.

## Android
Le site est responsive et préparé comme une PWA. Sur Android, une fois le site publié en HTTPS, ouvrir le site dans Chrome puis choisir le menu > Installer l'application / Ajouter à l'écran d'accueil (le libellé varie).
Pour un APK natif, il faudra ensuite utiliser un environnement Android comme Android Studio ou un service de compilation approprié. Ce ZIP ne contient pas un APK prêt à installer.

## Sécurité et limites
Prototype uniquement : aucune authentification persistante, aucun backend, aucun paiement, aucun transfert d'argent réel et aucun accès à des marchés. Ne collectez pas de données sensibles. Les soldes, transactions, taux et missions sont fictifs. Les fonctionnalités financières réelles peuvent nécessiter des prestataires réglementés, des autorisations, des procédures KYC/AML et une analyse juridique.
